/*
    Author: Jordan Cottle
    Created: 10/08/2020
*/

#include "simulation.h"

namespace Simulation
{
    EventQueue masterEventQueue;
    Clock simulationClock;
} // namespace Simulation
